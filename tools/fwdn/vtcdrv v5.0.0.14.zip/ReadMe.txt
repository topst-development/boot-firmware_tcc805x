===============================================
    VTC Driver Install/Uninstall Guide
===============================================

Note: From version 5.0.0.14, win2000 and ia64 are not supported.

1. Install

Windows XP/Vista/7 32bit:
 -> .\x86\VTC Driver Installer for x86.EXE

Windows XP/Vista/7 64bit:
 -> .\x64\VTC Driver Installer for x64.EXE

Windows 10 64bit:
 -> .\win10_x64\VTC Driver Installer for win10 x64.EXE



2. Uninstall


 User can uninstall the driver from the "Add or Remove Programs Tool" in "Control Panel".